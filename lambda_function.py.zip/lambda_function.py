from __future__ import print_function
import os
import sys, warnings
import boto3
from deepsecurity.rest import ApiException
from datetime import datetime
from pprint import pprint
import csv

from botocore.exceptions import ClientError
from typing import List
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from tempfile import TemporaryFile

import deepsecurity as ds
from deepsecurity.models.intrusion_prevention_rule import IntrusionPreventionRule
from deepsecurity.models.intrusion_prevention_rules import IntrusionPreventionRules


API_VERSION = "v1"
AWS_REGION = os.environ.get('region')
SENDER = os.environ.get('sender')
RECIPIENTS = os.environ.get('recipients')
API_KEY = os.environ.get("apikey")

########################################
# AWS_REGION = "us-east-1"
# SENDER = 'schadrach_welbeck@trendmicro.com'
# RECIPIENTS = 'schadrach_welbeck@trendmicro.com,schadrach_welbeck@trendmicro.com'
# API_KEY = 'tmc12BzGe1qV7P2I91vqeZvK7V8Ve7d:2t2hvThiaiENPML8boECm2Z7jqKzagRwkcsdFTakKp5xVCq3A6HBjqr5jmvK5ZnDEX'


def all_instance_details_from_inspector():
    # TODO: check for next token as max result is 50
    inspector = boto3.client("inspector2")
    instances = list()
    findings = inspector.list_finding_aggregations(
        aggregationType="AWS_EC2_INSTANCE",
        # aggregationRequest='AWS_EC2_INSTANCE',
        maxResults=50,
    )

    for f in findings["responses"]:
        instance_details = {
            "id": f["ec2InstanceAggregation"]["instanceId"],
            "name": f["ec2InstanceAggregation"].get("instanceTags", {}).get("Name"),
        }
        instances.append(instance_details)
    print("Found total instances =", len(instances))
    return instances


def cves_from_instance(instance_id):
    cves = list()
    result = list()
    inspector = boto3.client("inspector2")
    # print('instance', instance_id)
    resp = inspector.list_findings(
        filterCriteria={
            "findingStatus": [{"comparison": "EQUALS", "value": "ACTIVE"}],
            "resourceId": [{"comparison": "EQUALS", "value": instance_id}],
        }
    )
    result.extend(resp["findings"])
    next_token = resp.get("nextToken")
    while next_token:
        resp = inspector.list_findings(
            filterCriteria={
                "findingStatus": [{"comparison": "EQUALS", "value": "ACTIVE"}],
                "resourceId": [{"comparison": "EQUALS", "value": instance_id}],
            },
            nextToken=next_token
        )
        result.extend(resp["findings"])
        next_token = resp.get("nextToken")

    for finding in result:
        cve = finding.get("packageVulnerabilityDetails", {}).get("vulnerabilityId")
        if cve:
            cves.append(cve)
        # print(cve)
    return cves


def ds_config_and_version():
    # Setup
    if not sys.warnoptions:
        warnings.simplefilter("ignore")
    API_VERSION = "v1"
    conf = ds.Configuration()
    conf.host = "https://workload.trend-us-1.cloudone.trendmicro.com/api"
    conf.api_key[
        "Authorization"
    ] = f"ApiKey {API_KEY}"
    return conf, API_VERSION


def send_email(sender, recipients, subject, html_body, attachment):
    print('sending email ...')
        
    # Create a new SES resource and specify a region.
    client = boto3.client('ses',region_name=AWS_REGION)
    

    msg = MIMEMultipart()
    text_part = MIMEText(html_body, _subtype="html")
    msg.attach(text_part)

    filename='vulnerability_report.csv'
    msg["To"] = recipients
    msg["From"] = sender
    msg['Subject'] = subject
    
    part = MIMEApplication(attachment.read(), filename)
    part.add_header("Content-Disposition", 'attachment', filename=filename)
    msg.attach(part)
    
    client.send_raw_email(RawMessage={"Data" : msg.as_bytes()})


def lambda_handler(event, context):
    csv_rows = list()
    conf, api_version = ds_config_and_version()
    all_instance_details = all_instance_details_from_inspector()
    for instance_details in all_instance_details:
        instance_id = instance_details["id"]
        instance_name = instance_details["name"]

        print(instance_name, instance_id)
        cves = cves_from_instance(instance_id)
        print("inspector", cves)

        search_criteria = ds.SearchCriteria()
        search_criteria.field_name = 'ec2VirtualMachineSummary/instanceID'
        search_criteria.string_test = 'equal'
        search_criteria.string_value = instance_id

        # Create a search filter with maximum returned items
        search_filter = ds.SearchFilter()
        search_filter.search_criteria = [search_criteria]

        expand = ds.Expand(ds.Expand.intrusion_prevention)
        expand.add(ds.Expand.ec2_virtual_machine_summary)

        # Perform the search and do work on the results
        computers_api = ds.ComputersApi(ds.ApiClient(conf))
        rows = []

        computers = computers_api.search_computers(
            api_version, 
            search_filter=search_filter, 
            expand=expand.list(), 
            overrides=False
        )
        num_found = len(computers.computers)

        if num_found == 0:
            raise Exception(f"No computers found for instance id: {instance_id}")

        for computer in computers.computers:
            # print('ips', computer.intrusion_prevention)
            # print(computer.host_name)
            print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   id', computer.id)
            if computer.intrusion_prevention.rule_ids:
                for ipr_id in computer.intrusion_prevention.rule_ids:
                    print('>>>>>>>>> checking rule id:', ipr_id)
                    api_client = ds.ApiClient(configuration=conf)
                    api = ds.ComputerIntrusionPreventionRuleDetailsApi(api_client)
                    ipr = api.describe_intrusion_prevention_rule_on_computer(computer_id=computer.id, intrusion_prevention_rule_id=ipr_id, api_version=api_version)
                    if ipr.cve:
                        for cve in ipr.cve:
                            if cve in cves:
                                print(instance_id, computer.display_name, ipr.identifier, ipr.name, cve, ipr.severity, ipr.cvss_score)
                                csv_rows.append([instance_id, computer.display_name, ipr.identifier, ipr.name, cve, ipr.severity, ipr.cvss_score])

    csv_file = TemporaryFile(mode='w+', newline='')
    writer = csv.writer(csv_file)
    csv_header = ["instance_id", "computer", "ipr identifier", "ipr name", "cve", "severity", "cvss_score"]
    writer.writerow(csv_header)
    for row in csv_rows:
        writer.writerow(row)
    csv_file.seek(0)
        
    # The subject line for the email.
    subject = "Vulnrebility Report (CVEs) from Amazon Inspector"

    protected_cves_html = '<table border="1">' + '\n'
    # write headers
    protected_cves_html += '</tr>' + '\n'
    for col in csv_header:
        protected_cves_html += f'<th>{col}</th>' + '\n'
    protected_cves_html += '</tr>' + '\n'
    # write rows
    for row in csv_rows:
        protected_cves_html += '<tr>' + '\n'
        for col in row:
            protected_cves_html += f'<td>{col}</td>' + '\n'
        protected_cves_html += '</tr>' + '\n'
    protected_cves_html += '</table>'
                    
    # The HTML body of the email. 
    body_html = f"""<html>
    <head></head>
    <body>
      <h1>Protected CVEs</h1>
      {protected_cves_html}
    </body>
    </html>
    """            
    
    send_email(SENDER, RECIPIENTS, subject, body_html, csv_file)


# lambda_handler(None, None)
